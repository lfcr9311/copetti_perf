
#include <FileConstants.au3>

#RequireAdmin

$exe = 'takeoff.exe'

$source = '"' & @ScriptDir & '"'
$destination =  "C:\AZULTakeoff Module\"




$process = ProcessExists($exe)

IF $process <> 0 Then
$msgbox = MsgBox ( "", "Atualiza��o do Azul TakeOff Module", "O ATOM precisa ser fechado para ser atualizado, clique em OK para continuar" )
ProcessClose ($exe)

Runwait(@ComSpec & " /c " & "xcopy " & '"' & $source & '"' & ' "' & $destination & '"' & " /S /Q /Y /F", "", @SW_HIDE)
FileCreateShortcut("C:\AZULTakeoff Module\takeoff.exe", @DesktopCommonDir & "\ATOM.lnk", "C:\AZULTakeoff Module\", "", "", "", "C:\AZULTakeoff Module\takeoff.ico", "", "")


Else

Runwait(@ComSpec & " /c " & "xcopy " & '"' & $source & '"' & ' "' & $destination & '"' & " /S /Q /Y /F", "", @SW_HIDE)
FileCreateShortcut("C:\AZULTakeoff Module\takeoff.exe", @DesktopCommonDir & "\ATOM.lnk", "C:\AZULTakeoff Module\", "", "", "", "C:\AZULTakeoff Module\takeoff.ico", "", "")



EndIf


